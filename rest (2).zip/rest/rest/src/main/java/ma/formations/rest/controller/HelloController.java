package ma.formations.rest.controller;

// Rappel : ce package sera scanné par @SpringBootApplication
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @RequestMapping(value = { "/hello", "/" })
    public String hello() {
        System.out.println("Ce package sera scanné par @SpringBootApplication");
        return "Hello World from my first API @RestController";
    }
}
