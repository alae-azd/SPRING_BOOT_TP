package ma.formations.springmvc_rest_data_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcRestDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
