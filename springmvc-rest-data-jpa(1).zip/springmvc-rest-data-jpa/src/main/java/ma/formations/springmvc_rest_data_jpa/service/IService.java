package ma.formations.springmvc_rest_data_jpa.service;


import java.util.List;
import ma.formations.springmvc_rest_data_jpa.domaine.EmpVo;

public interface IService {
    List<EmpVo> getEmployees();
    void save(EmpVo emp);
    EmpVo getEmpById(Long id);
    void delete(Long id);
    List<EmpVo> findBySalary(Double salary);
    List<EmpVo> findByFonction(String fonction);
    List<EmpVo> findBySalaryAndFonction(Double salary, String fonction);
    EmpVo getEmpHavaingMaxSalary();

    // Pour la pagination
    List<EmpVo> findAll(int pageId, int size);

    // Pour le tri
    List<EmpVo> sortBy(String fieldName);
}